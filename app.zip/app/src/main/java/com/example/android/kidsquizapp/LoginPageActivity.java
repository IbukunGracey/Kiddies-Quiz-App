package com.example.android.kidsquizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

public class LoginPageActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
    }

    public void beginMainMenu(View view){

        userName();
        userAge();


        /**
        if (age = || name == null){

            Toast.makeText(this,"Please enter your details", Toast.LENGTH_SHORT ).show();
            return;

        } else if(age <= 5 ){

        }

         */

        if (userAge() < 5 ){
            // Show an error message as a toast when the user's age is less than 5years
            Toast toast = Toast.makeText(this,"Your are too young to take this Quiz! \n Your age should be between 5 to 10 years", Toast.LENGTH_SHORT );
            toast.show();
            // Exit this method early because there is nothing left to do

        } else
            if (userAge() > 10 ){
                // Show an error message as a toast when the user's age is more than 10years
                Toast toast = Toast.makeText(this,"Your are too old to take this Quiz! \n Your age should be between 5 to 10 years", Toast.LENGTH_SHORT );
                toast.show();
                // Exit this method early because there is nothing left to do

        }
         /**   else
            if (TextUtils.isEmpty(userName())){
                // Show an error message as a toast when the user does not enter his name.
                Toast.makeText(this,"Please enter your Name", Toast.LENGTH_SHORT ).show();


        } else
            if (Integer.toString(userAge()).isEmpty()){
                // Show an error message as a toast when the user does not enter his age.
                Toast.makeText(this,"Please enter your Age", Toast.LENGTH_SHORT ).show();

        } */
        else {
                // Create an implicit intent to the  main menu.
                Intent beginIntent = new Intent(LoginPageActivity.this, MainMenu.class);
                startActivity(beginIntent);
                finish();
                return;

        }


    }

    // Collect the name of the user

    public String userName(){

        EditText nameText = findViewById(R.id.edit_name_text);
        String name = nameText.getText().toString();
        return (name);
    }

    /**
     * This method displays the given age of the user on the screen.
     */
    public int userAge(){

        EditText ageText = findViewById(R.id.edit_age_text);
        String ageValue = ageText.getText().toString();
        int ageFinal = Integer.parseInt(ageValue);
        return (ageFinal);
    }

    public void resultSummary(String name, int Age, int Score, boolean userPassed, boolean userFailed){

    }


}
