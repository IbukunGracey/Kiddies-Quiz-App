package com.example.android.kidsquizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    public void beginMathsQuiz(View view){
        Intent mathsIntent = new Intent(this, MathematicsQuiz.class);
        startActivity(mathsIntent);
        finish();
    }

    public void beginEnglishQuiz(View view){
        Intent englishIntent = new Intent(this, EnglishQuiz.class);
        startActivity(englishIntent);
        finish();
    }

    public void beginPersonalityQuiz(View view){
        Intent personalityIntent = new Intent(this, PersonalityQuiz.class);
        startActivity(personalityIntent);
        finish();
    }
}
