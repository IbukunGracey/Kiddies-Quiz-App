package com.example.android.kidsquizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

public class MathematicsQuiz extends AppCompatActivity {
    int mathsScore = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mathematics_quiz);
    }

    // This method takes the user to the main menu

    public void goToMainMenu(View view){
        Intent mainMenuIntent = new Intent(this, MainMenu.class);
        startActivity(mainMenuIntent);
        finish();
    }

    // This method takes the user to the Result menu

    public void submitMathsAnswer(View view){
        /**
         * This method checks whether the user selects option1, question1
         */
        // figure out whether the user checked option1, question1

        LoginPageActivity loginPageActivity = new LoginPageActivity();
        String name = loginPageActivity.userName();
        int age = loginPageActivity.userAge();

        //String summary =createResultSummary(scoreTotal(),name, age);
        //displayMessage(summary);

        Intent mathsAnswersIntent = new Intent(this, Result.class);
        startActivity(mathsAnswersIntent);
        finish();

    }

    /**
     * This method checks whether the user selects option1, question1


    private boolean checkedQuestion1(){
        RadioButton q1Option1 = findViewById(R.id.q1_opt1_radio_button);
        boolean q1Option1Checked = q1Option1.isChecked();
        return q1Option1Checked;
    }
     */


    public int calculateAnswerQ1(){

        // figure out whether the user checked option1, question1
        RadioButton q1Option4 = (RadioButton) findViewById(R.id.q1_opt4_radio_button);
        boolean q1Option4Checked = q1Option4.isChecked();

        if(q1Option4Checked){
            mathsScore +=1;
        } else {
            mathsScore += 0;
        }
        return mathsScore;

    }
    //Sum of user total score
    public int scoreTotal(){
        mathsScore = calculateAnswerQ1();
        return mathsScore;
    }

    /**
     * This method displays the given text on the screen.
     */
    private void displayMessage(String message) {
        TextView messageSummaryTextView = (TextView) findViewById(R.id.message_summary);
        messageSummaryTextView.setText(message);
    }

    // This displays summary of users result
    public String createResultSummary(int score, String name, int age){
        String resultMessage = "Thank you for taking this quiz Amazing " + name + "!";
        resultMessage += "\nAge:" + age;
        resultMessage += "\nQuestion 1: Your Answer is";
        resultMessage += "\nTotal score " + scoreTotal();
        resultMessage = resultMessage  + "\n\nThank You for taking part in the Quiz!";
        return resultMessage;

    }

}
